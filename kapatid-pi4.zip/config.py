"""
KAPATID-VIBE — configuration for Raspberry Pi 4 Model B (4GB).

Everything you might need to change lives in this file.
Check AUDIO_DEVICE after your first run; everything else has a safe default.
"""

# ---------------------------------------------------------------------------
# AUDIO
# ---------------------------------------------------------------------------
# Which sound card to play through.
#
#   None            -> system default (risky: may pick HDMI)
#   "Headphones"    -> the Pi 4's built-in 3.5mm jack. Works, but it is an
#                      11-bit PWM/sigma-delta output with dither, so it
#                      hisses noticeably.
#   "USB"           -> a USB audio adapter. RECOMMENDED. About PHP 300 and
#                      the single biggest audio-quality gain available to
#                      this build. Draws ~50-100 mA of the Pi 4's 1.2 A
#                      USB budget, which you are not otherwise using.
#
# Run `python3 -m sounddevice` on the Pi to list exact names.
#
# NOTE: Raspberry Pi OS uses PipeWire. If PipeWire is holding the card,
# opening a raw "hw:0,0" fails. Prefer the name shown by the command above,
# or "default" / "pulse".
AUDIO_DEVICE = "USB"

# ---------------------------------------------------------------------------
# MOTOR PWM MODE
# ---------------------------------------------------------------------------
# "software" is the default and the right choice for a vibration motor.
#
# Why: an eccentric-mass motor has 20-50 ms of mechanical inertia, so it
# physically cannot respond to PWM jitter. Software PWM is entirely adequate,
# needs no device-tree overlay, and avoids a subtlety explained below.
#
# The subtlety, for the record: on a Pi 3 the 3.5mm jack and hardware PWM
# share one PWM controller and genuinely conflict. On a Pi 4 (BCM2711) there
# are TWO independent PWM controllers -- the jack sits on pwm1/GPIO40-41
# while `dtoverlay=pwm-2chan` drives pwm0/GPIO12-13 -- so the channel-level
# conflict is gone. However both blocks are fed from one shared clock
# generator, and Raspberry Pi still ships this warning for BCM2711:
#     "The onboard analogue audio output uses both PWM channels.
#      So be careful mixing audio and PWM."
# Rather than rely on that being benign, use software PWM. If you switch to
# "hardware", add to /boot/firmware/config.txt:
#     dtoverlay=pwm-2chan,pin=12,func=4,pin2=13,func2=4
# and then verify audio still works:  speaker-test -c2 -t wav
PWM_MODE = "software"

PWM_SOFT_FREQUENCY = 1000   # Hz. Used in "software" mode.
PWM_FREQUENCY = 20000       # Hz. Used in "hardware" mode only.

# ---------------------------------------------------------------------------
# GPIO PIN MAP  (BCM numbering)
# ---------------------------------------------------------------------------
# The Pi 4 header is fully backwards compatible with the Pi 3, so this map
# is identical on either board.
#
# Buttons wire exactly as they did on the Arduino: pin -> button -> GND.
# Internal pull-ups are enabled in software, no resistors needed.
PIN_DEAF = 17
PIN_BLIND = 27
PIN_CHILD = 22
PIN_FOREIGN = 23
PIN_ENGLISH = 24
PIN_SPANISH = 25
PIN_MANDARIN = 5

# Optional: momentary button, held 2 s, cleanly powers the Pi down.
# Protects the SD card. Set to None if you are not fitting one.
PIN_SHUTDOWN = 21

# TB6612FNG motor driver.
#   PWM  -> PWMA
#   IN1  -> AIN1
#   IN2  -> AIN2
#   STBY -> STBY   (held low at boot so the motor cannot twitch on power-up)
PIN_MOTOR_PWM = 12
PIN_MOTOR_IN1 = 6
PIN_MOTOR_IN2 = 16
PIN_MOTOR_STBY = 26

# I2C for the LCD uses GPIO2 (SDA) and GPIO3 (SCL). Not configurable.
# (A Pi 4 actually has up to 6 I2C buses via dtoverlay=i2c3..i2c6 if you
# ever need to move the display off bus 1. A Pi 3 cannot do that.)

# ---------------------------------------------------------------------------
# LCD
# ---------------------------------------------------------------------------
LCD_ADDRESS = 0x27        # try 0x3F if the screen stays blank
LCD_COLS = 16
LCD_ROWS = 2
# Most cheap PCF8574 backpacks are 'A00'. If you see garbled characters,
# switch this to 'A02'.
LCD_CHARMAP = "A00"

# ---------------------------------------------------------------------------
# BEHAVIOUR  (matches the original Arduino sketch)
# ---------------------------------------------------------------------------
MORSE_UNIT = 0.150        # seconds. Was `#define UNIT 150` on the Arduino.
MORSE_TEXT = "Sarswela"
BOUNCE_TIME = 0.08        # seconds a button must be stable before it counts

# Motor intensity, 0.0-1.0.
# An eccentric-mass motor will not start below roughly 0.35-0.40, so each
# pulse kicks briefly to KICK_LEVEL before settling at MORSE_LEVEL.
MORSE_LEVEL = 0.85
KICK_LEVEL = 1.0
KICK_TIME = 0.025         # seconds of full power to break stiction

# Where the audio lives, and which file each mode plays.
SOUNDS_DIR = "Sounds"
AUDIO_FILES = {
    "blind": "Blind.mp3",
    "child": "Child.mp3",
    "english": "English.mp3",
    "spanish": "Spanish.mp3",
    "mandarin": "Mandarin.mp3",
}
