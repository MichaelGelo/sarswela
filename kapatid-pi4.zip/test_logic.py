#!/usr/bin/env python3
"""
Behavioural tests: does the Pi port do what the Arduino sketch did?

Runs anywhere (no Pi needed). Each test asserts against the behaviour of
src/main.cpp so we can prove parity before buying hardware.
"""

import sys
import time
import unittest
from unittest import mock

import config
import hardware
import kapatid


class FakeLcd:
    def __init__(self):
        self.history = []

    def show(self, line1, line2=""):
        entry = (line1, line2)
        if not self.history or self.history[-1] != entry:
            self.history.append(entry)

    def close(self):
        pass


class FakeMotor:
    def __init__(self):
        self.events = []
        self.on_count = 0

    def on(self, level=None):
        self.on_count += 1
        self.events.append(("on", level))

    def off(self):
        self.events.append(("off", None))

    def close(self):
        pass


class FakeAudio:
    def __init__(self):
        self.played = []
        self.stops = 0

    def play(self, path):
        # Mirrors the real Audio.play(), which cuts off the previous clip
        # before starting a new one.
        self.stop()
        self.played.append(path.split("/")[-1])

    def stop(self):
        self.stops += 1

    def close(self):
        pass


class FakeButtons:
    def __init__(self, on_press, on_release=None):
        self.on_press = on_press

    def close(self):
        pass


class ParityTests(unittest.TestCase):
    def setUp(self):
        patches = [
            mock.patch.object(hardware, "Lcd", FakeLcd),
            mock.patch.object(hardware, "Motor", FakeMotor),
            mock.patch.object(hardware, "Audio", FakeAudio),
            mock.patch.object(hardware, "Buttons", FakeButtons),
        ]
        for patch in patches:
            patch.start()
            self.addCleanup(patch.stop)
        self.app = kapatid.Kapatid()
        self.addCleanup(self.app.close)

    # -- LCD --------------------------------------------------------------

    def test_idle_message_on_startup(self):
        """Arduino calls displayMessage(7) in setup()."""
        self.assertEqual(self.app.lcd.history[0], ("Select a mode", ""))

    def test_all_eight_lcd_states_reachable(self):
        expected = {
            "deaf": ("Deaf Mode", ""),
            "blind": ("Blind Mode", ""),
            "child": ("Child Mode", ""),
            "foreign": ("Foreign Lang", "Mode"),
            "english": ("English", ""),
            "spanish": ("Spanish", ""),
            "mandarin": ("Mandarin", ""),
        }
        self.app.on_press("foreign")   # arm the gate for the language modes
        for name, text in expected.items():
            self.app.on_press(name)
            self.assertEqual(self.app.lcd.history[-1], text,
                             f"LCD wrong for {name}")

    def test_repeated_identical_writes_are_suppressed(self):
        """Arduino guards with `if (state == lastState) return;`"""
        self.app.on_press("blind")
        before = len(self.app.lcd.history)
        self.app.on_press("blind")
        self.assertEqual(len(self.app.lcd.history), before)

    # -- Foreign-language gate -------------------------------------------

    def test_language_buttons_ignored_before_foreign(self):
        """`foreignGate` starts false, so these must do nothing."""
        for name in ("english", "spanish", "mandarin"):
            self.app.on_press(name)
        self.assertEqual(self.app.audio.played, [])
        self.assertEqual(self.app.lcd.history[-1], ("Select a mode", ""))

    def test_language_buttons_work_after_foreign(self):
        self.app.on_press("foreign")
        self.app.on_press("english")
        self.assertEqual(self.app.audio.played, ["English.mp3"])

    def test_gate_closes_when_another_mode_chosen(self):
        """Arduino sets foreignGate = false in the deaf/blind/child branches."""
        self.app.on_press("foreign")
        self.app.on_press("blind")
        self.app.on_press("spanish")     # gate should now be shut
        self.assertNotIn("Spanish.mp3", self.app.audio.played)

    # -- Audio ------------------------------------------------------------

    def test_each_mode_plays_the_right_clip(self):
        self.app.on_press("blind")
        self.app.on_press("child")
        self.app.on_press("foreign")
        self.app.on_press("english")
        self.app.on_press("spanish")
        self.app.on_press("mandarin")
        self.assertEqual(
            self.app.audio.played,
            ["Blind.mp3", "Child.mp3", "English.mp3",
             "Spanish.mp3", "Mandarin.mp3"])

    def test_new_clip_stops_the_previous_one(self):
        """audio_player.py calls sd.stop() before every sd.play()."""
        self.app.on_press("blind")
        self.app.on_press("child")
        self.assertGreaterEqual(self.app.audio.stops, 1)

    def test_deaf_and_foreign_send_stop(self):
        """Both emitted Serial 'STOP' on the Arduino."""
        self.app.on_press("blind")
        before = self.app.audio.stops
        self.app.on_press("deaf")
        self.assertGreater(self.app.audio.stops, before)
        before = self.app.audio.stops
        self.app.on_press("foreign")
        self.assertGreater(self.app.audio.stops, before)

    # -- Morse ------------------------------------------------------------

    def test_deaf_mode_drives_the_motor(self):
        self.app.on_press("deaf")
        time.sleep(0.5)
        self.assertGreater(self.app.motor.on_count, 0)

    def test_morse_is_interrupted_by_another_button(self):
        """The Arduino's interruptibleDelay() aborted Morse on any press.

        "Sarswela" is ~50 units; at 150 ms that is over 7 seconds. If the
        cancel works, pressing Blind returns almost immediately and the
        motor stops.
        """
        self.app.on_press("deaf")
        time.sleep(0.3)
        started = time.monotonic()
        self.app.on_press("blind")
        elapsed = time.monotonic() - started
        self.assertLess(elapsed, 1.0, "cancel took too long")
        self.assertFalse(self.app._morse_thread
                         and self.app._morse_thread.is_alive())
        self.assertEqual(self.app.motor.events[-1][0], "off",
                         "motor must be left braked")

    def test_morse_restarts_cleanly_on_second_press(self):
        """Arduino re-arms via `if (digitalRead(deaf_mode) == HIGH)`."""
        self.app.on_press("deaf")
        time.sleep(0.2)
        self.app.on_press("deaf")
        time.sleep(0.2)
        self.assertTrue(self.app._morse_thread.is_alive())

    def test_motor_is_off_after_shutdown(self):
        self.app.on_press("deaf")
        time.sleep(0.2)
        self.app.close()
        self.assertEqual(self.app.motor.events[-1][0], "off")

    # -- Morse table ------------------------------------------------------

    def test_morse_table_matches_arduino(self):
        arduino = [
            ".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..",
            ".---", "-.-", ".-..", "--", "-.", "---", ".--.", "--.-", ".-.",
            "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--..",
        ]
        for index, pattern in enumerate(arduino):
            letter = chr(ord("A") + index)
            self.assertEqual(kapatid.MORSE_TABLE[letter], pattern,
                             f"Morse mismatch for {letter}")

    def test_sarswela_encodes_correctly(self):
        expected = "... .- .-. ... .-- . .-.. .-"
        actual = " ".join(kapatid.MORSE_TABLE[c]
                          for c in config.MORSE_TEXT.upper())
        self.assertEqual(actual, expected)

    # -- Config sanity ----------------------------------------------------

    def test_no_duplicate_gpio_pins(self):
        pins = [config.PIN_DEAF, config.PIN_BLIND, config.PIN_CHILD,
                config.PIN_FOREIGN, config.PIN_ENGLISH, config.PIN_SPANISH,
                config.PIN_MANDARIN, config.PIN_MOTOR_PWM,
                config.PIN_MOTOR_IN1, config.PIN_MOTOR_IN2,
                config.PIN_MOTOR_STBY]
        if config.PIN_SHUTDOWN is not None:
            pins.append(config.PIN_SHUTDOWN)
        self.assertEqual(len(pins), len(set(pins)), "duplicate GPIO assigned")

    def test_no_pin_collides_with_i2c(self):
        """GPIO2/3 belong to the LCD bus and must not be reused."""
        pins = [config.PIN_DEAF, config.PIN_BLIND, config.PIN_CHILD,
                config.PIN_FOREIGN, config.PIN_ENGLISH, config.PIN_SPANISH,
                config.PIN_MANDARIN, config.PIN_MOTOR_PWM,
                config.PIN_MOTOR_IN1, config.PIN_MOTOR_IN2,
                config.PIN_MOTOR_STBY]
        self.assertNotIn(2, pins)
        self.assertNotIn(3, pins)

    def test_hardware_pwm_uses_a_real_pwm_pin(self):
        if config.PWM_MODE == "hardware":
            self.assertIn(config.PIN_MOTOR_PWM, (12, 13, 18, 19))

    def test_hardware_pwm_not_combined_with_the_headphone_jack(self):
        """The 3.5mm jack IS the PWM peripheral. Both is impossible."""
        if config.PWM_MODE == "hardware":
            self.assertNotEqual(config.AUDIO_DEVICE, "Headphones")


if __name__ == "__main__":
    unittest.main(verbosity=2)
