"""
Hardware abstraction for KAPATID-VIBE.

Every piece of hardware is behind a small class here. On a Raspberry Pi the
real drivers load; anywhere else (your laptop, CI) they fall back to mocks
that print what they would have done. That means the whole state machine can
be tested before the board arrives.
"""

import sys
import threading
import time

import config

# --- Detect whether we are on real hardware -------------------------------

ON_PI = False
try:
    with open("/proc/device-tree/model", "rb") as handle:
        ON_PI = b"Raspberry Pi" in handle.read()
except OSError:
    ON_PI = False


# ===========================================================================
#  LCD
# ===========================================================================

class Lcd:
    """16x2 character LCD on an I2C backpack.

    Writes are serialised behind a lock. An I2C write takes a few
    milliseconds, which is far too slow to do from inside an audio callback,
    so only ever call this from the main thread or a button handler.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._last = None
        self._dev = None
        if ON_PI:
            from RPLCD.i2c import CharLCD
            self._dev = CharLCD(
                i2c_expander="PCF8574",
                address=config.LCD_ADDRESS,
                port=1,
                cols=config.LCD_COLS,
                rows=config.LCD_ROWS,
                charmap=config.LCD_CHARMAP,
                auto_linebreaks=False,
            )
            self._dev.clear()
            self._dev.backlight_enabled = True

    def show(self, line1, line2=""):
        """Display up to two lines. Repeated identical calls are ignored,
        which is what stopped the Arduino LCD from flickering."""
        payload = (line1[:config.LCD_COLS], line2[:config.LCD_COLS])
        with self._lock:
            if payload == self._last:
                return
            self._last = payload
            if self._dev is not None:
                self._dev.clear()
                self._dev.cursor_pos = (0, 0)
                self._dev.write_string(payload[0])
                if payload[1]:
                    self._dev.cursor_pos = (1, 0)
                    self._dev.write_string(payload[1])
            else:
                print(f"[LCD] {payload[0]!r} / {payload[1]!r}")

    def close(self):
        with self._lock:
            if self._dev is not None:
                self._dev.clear()
                self._dev.backlight_enabled = False
                self._dev.close()


# ===========================================================================
#  MOTOR  (TB6612FNG)
# ===========================================================================

class Motor:
    """Haptic motor behind a TB6612FNG driver.

    Replaces the Arduino's relay. Three improvements over the relay:
      * intensity is variable, not just on/off
      * switching is silent (no relay click in a quiet theatre)
      * brake() actively stops the eccentric mass instead of letting it coast
    """

    def __init__(self):
        self._pwm = None
        self._in1 = None
        self._in2 = None
        self._stby = None
        self._level = 0.0

        if not ON_PI:
            return

        from gpiozero import DigitalOutputDevice

        # STBY starts low: the driver is in standby until we are ready, so
        # the motor cannot twitch while the Pi boots.
        self._stby = DigitalOutputDevice(config.PIN_MOTOR_STBY,
                                         initial_value=False)
        self._in1 = DigitalOutputDevice(config.PIN_MOTOR_IN1,
                                        initial_value=False)
        self._in2 = DigitalOutputDevice(config.PIN_MOTOR_IN2,
                                        initial_value=False)

        if config.PWM_MODE == "hardware":
            # Kernel sysfs PWM. Needs dtoverlay=pwm-2chan in config.txt.
            # chip=0 is correct for Pi 1-4 on every kernel (Pi 5 needs
            # chip=2 below kernel 6.12). Channel 0 == GPIO12, 1 == GPIO13.
            from rpi_hardware_pwm import HardwarePWM
            channel = 0 if config.PIN_MOTOR_PWM == 12 else 1
            self._pwm = HardwarePWM(pwm_channel=channel,
                                    hz=config.PWM_FREQUENCY, chip=0)
            self._pwm.start(0)
            self._hardware_pwm = True
        else:
            # Thread-timed software PWM via the lgpio backend. Perfectly
            # adequate here: an eccentric-mass motor has 20-50 ms of
            # mechanical inertia and cannot respond to PWM jitter. Needs no
            # overlay and touches no shared peripheral.
            from gpiozero import PWMOutputDevice
            self._pwm = PWMOutputDevice(config.PIN_MOTOR_PWM,
                                        frequency=config.PWM_SOFT_FREQUENCY,
                                        initial_value=0.0)
            self._hardware_pwm = False

        self._stby.on()   # bring the driver out of standby

    def _apply(self, level):
        self._level = level
        if self._pwm is None:
            print(f"[MOTOR] {level:.2f}")
            return
        if self._hardware_pwm:
            self._pwm.change_duty_cycle(level * 100.0)
        else:
            self._pwm.value = level

    def on(self, level=None):
        """Spin the motor. Applies a brief full-power kick first, because an
        eccentric-mass motor will not start from rest at low duty."""
        level = config.MORSE_LEVEL if level is None else level
        if self._in1 is not None:
            self._in1.on()
            self._in2.off()
        if level < 1.0:
            self._apply(config.KICK_LEVEL)
            time.sleep(config.KICK_TIME)
        self._apply(level)

    def off(self):
        """Brake: shorts the motor windings so the mass stops promptly
        instead of coasting. TB6612 truth table -> IN1 high, IN2 high."""
        self._apply(0.0)
        if self._in1 is not None:
            self._in1.on()
            self._in2.on()

    def close(self):
        self.off()
        if self._stby is not None:
            self._stby.off()
        for device in (self._pwm, self._in1, self._in2, self._stby):
            if device is None:
                continue
            try:
                device.stop() if hasattr(device, "stop") else device.close()
            except Exception:
                pass


# ===========================================================================
#  AUDIO
# ===========================================================================

class Audio:
    """Plays the narration clips.

    Streams from disk rather than loading whole files, so a long clip cannot
    exhaust the Pi 3 B+'s 1 GB of RAM.
    """

    def __init__(self):
        self._thread = None
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._sd = None
        self._sf = None
        try:
            import sounddevice
            import soundfile
            self._sd = sounddevice
            self._sf = soundfile
            if config.AUDIO_DEVICE:
                sounddevice.default.device = config.AUDIO_DEVICE
        except Exception as exc:                    # pragma: no cover
            print(f"[AUDIO] library unavailable ({exc}); running silent",
                  file=sys.stderr)

    def _worker(self, path):
        try:
            with self._sf.SoundFile(path) as handle:
                stream = self._sd.OutputStream(
                    samplerate=handle.samplerate,
                    channels=handle.channels,
                    dtype="float32",
                )
                with stream:
                    for block in handle.blocks(blocksize=2048,
                                               dtype="float32"):
                        if self._stop.is_set():
                            break
                        stream.write(block)
        except Exception as exc:                    # pragma: no cover
            print(f"[AUDIO] playback failed: {exc}", file=sys.stderr)

    def play(self, path):
        """Start a clip, cutting off whatever was already playing."""
        self.stop()
        if self._sd is None or self._sf is None:
            print(f"[AUDIO] play {path}")
            return
        with self._lock:
            self._stop = threading.Event()
            self._thread = threading.Thread(
                target=self._worker, args=(path,), daemon=True)
            self._thread.start()

    def stop(self):
        with self._lock:
            thread, event = self._thread, self._stop
        if thread is not None and thread.is_alive():
            event.set()
            thread.join(timeout=1.0)
        if self._sd is None:
            print("[AUDIO] stop")

    def close(self):
        self.stop()


# ===========================================================================
#  BUTTONS
# ===========================================================================

class Buttons:
    """The seven mode buttons, wired pin -> switch -> GND as before.

    Note on debounce: the modern lgpio backend treats bounce_time as "the
    signal must be stable for this long before I report it", which is the
    opposite of old RPi.GPIO's "ignore further edges for this long". The
    practical effect is the same for a human pressing a button.
    """

    NAMES = ("deaf", "blind", "child", "foreign",
             "english", "spanish", "mandarin")

    def __init__(self, on_press, on_release=None):
        self._devices = {}
        pins = {
            "deaf": config.PIN_DEAF,
            "blind": config.PIN_BLIND,
            "child": config.PIN_CHILD,
            "foreign": config.PIN_FOREIGN,
            "english": config.PIN_ENGLISH,
            "spanish": config.PIN_SPANISH,
            "mandarin": config.PIN_MANDARIN,
        }
        if not ON_PI:
            print("[BUTTONS] mock mode")
            return

        from gpiozero import Button
        for name, pin in pins.items():
            button = Button(pin, pull_up=True, bounce_time=config.BOUNCE_TIME)
            button.when_pressed = (lambda n=name: on_press(n))
            if on_release is not None:
                button.when_released = (lambda n=name: on_release(n))
            self._devices[name] = button

        if config.PIN_SHUTDOWN is not None:
            holder = Button(config.PIN_SHUTDOWN, pull_up=True, hold_time=2.0)
            holder.when_held = self._shutdown
            self._devices["shutdown"] = holder

    @staticmethod
    def _shutdown():
        import subprocess
        print("[SYSTEM] shutdown requested")
        subprocess.run(["sudo", "shutdown", "-h", "now"], check=False)

    def close(self):
        for device in self._devices.values():
            try:
                device.close()
            except Exception:
                pass
